library(ggplot2)

Palette_fill <- scale_fill_manual(values=c("#FF6600","#660066","#FFFFFF"))
Palette_colour <- scale_colour_manual(values=c("#FF6600","#660066","#000000"))
Palette_size <- scale_size_manual(values=c(1,1,1,1,1,1,1,1,1,1))
Palette_linetype <- scale_linetype_manual(values=c("solid","solid","solid","solid","solid","solid","solid","solid","solid","solid"))

imgname <- "PROP_FREQ.2_Union_SRSF2.prop_freq.txt_negatively_charged_Vs_positively_chargedII_figures.png"
newtitle <- "PROP_FREQ.2_Union_SRSF2.prop_freq.txt"
file <-"PROP_FREQ.2_Union_SRSF2.prop_freq.txt_negatively_charged_Vs_positively_chargedII_figures.txt"


M <- read.table(file,sep="\t",header=TRUE)
names(M) <- c("group","freq_negatively_charged_Vs_positively_chargedII")
#str(M)
#levels(M$group)

T0_1<-ks.test(M$freq_negatively_charged_Vs_positively_chargedII[M$group=="UP"],M$freq_negatively_charged_Vs_positively_chargedII[M$group=="DOWN"])

newtitle <- paste0(newtitle,"\n","[ks.test] ","UP-DOWN:",signif(T0_1$p.value,4),"  ")
T0_1
signif(T0_1$p.value,4)


# Reorder groups
M$group <- factor(M$group,levels = c("UP","DOWN"))
# + coord_cartesian(xlim=c(0,1))
ggp <- ggplot(M,aes(freq_negatively_charged_Vs_positively_chargedII)) + Palette_fill + Palette_colour 
#ggt <- theme_bw(base_size = 48)
ggt <- theme_bw()
ggt2 <- theme(axis.text.x = element_text(colour="black",size=48,angle=90,hjust=.5,vjust=.5,face="bold"),
              axis.text.y = element_text(colour="black",size=48,angle=0,hjust=1,vjust=0,face="bold"),
              axis.title.x = element_text(colour="black",size=20,angle=0,hjust=.5,vjust=0,face="bold"),
              axis.title.y = element_text(colour="black",size=48,angle=90,hjust=.5,vjust=.5,face="bold"),
              legend.title=element_text(size=20,face="bold"),
              legend.text=element_text(size=20),
              plot.title = element_text(size = 12, face = "plain"))

# colour="grey20" "black",face = "bold" "plain"

ggd <- geom_density(size=3, kernel="gaussian",alpha=0)
ggh <- geom_histogram(position="dodge",alpha=0.4,aes(y=..density..),binwidth=0.05)

png(file = imgname )
ggp + ggt + ggt2 + geom_histogram(position="dodge",alpha=0.8,aes(y=..density..,fill=group),binwidth=0.05) + geom_density(aes(colour=group),size=3,kernel="gaussian",alpha=0) + ggtitle(newtitle)
dev.off()

q()
n
